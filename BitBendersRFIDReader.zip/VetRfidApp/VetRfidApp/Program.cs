﻿using Fleck;
using System;
using System.Collections.Generic;
using System.IO.Ports;

class Program
{
    static List<IWebSocketConnection> allSockets = new List<IWebSocketConnection>();
    static SerialPort serialPort;

    static void Main(string[] args)
    {
        // WebSocket Server Başlat
        FleckLog.Level = LogLevel.Warn;
        var server = new WebSocketServer("ws://0.0.0.0:5000");

        server.Start(socket =>
        {
            socket.OnOpen = () =>
            {
                Console.WriteLine("Web bağlantısı kuruldu.");
                allSockets.Add(socket);
            };

            socket.OnClose = () =>
            {
                Console.WriteLine("Web bağlantısı kapandı.");
                allSockets.Remove(socket);
            };

            socket.OnError = ex =>
            {
                Console.WriteLine("WebSocket Hatası: " + ex.Message);
            };
        });

        // Arduino SerialPort Ayarı
        serialPort = new SerialPort("COM4", 9600); // ← Portunu buraya yaz
        serialPort.DataReceived += SerialPort_DataReceived;
        serialPort.Open();

        Console.WriteLine("WebSocket + RFID servisi çalışıyor. Çıkmak için Enter’a bas.");
        Console.ReadLine();
    }

    static void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
    {
        string uid = serialPort.ReadLine().Trim();
        if (uid == "2906178668")
        {
            uid = "3";
            Console.WriteLine("Kart Okundu: " + "3");
        }

        if (uid == "4247508332")
        {
            uid = "4";
            Console.WriteLine("Kart Okundu: " + "4");
        }
        
        if (uid == "1731876300")
        {
            uid = "5";
            Console.WriteLine("Kart Okundu: " + "5");
        }

        if (uid == "3438893156")
        {
            uid = "6";
            Console.WriteLine("Kart Okundu: " + "6");
        }
        

        foreach (var socket in allSockets)
        {
            socket.Send(uid);
        }
    }
}