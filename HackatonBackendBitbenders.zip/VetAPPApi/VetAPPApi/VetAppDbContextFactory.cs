﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using VetAPPApi;
using VetAppApi.Data;

namespace VetAppApi.Data
{
    public class VetAppDbContextFactory : IDesignTimeDbContextFactory<VetAppDbContext>
    {
        public VetAppDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<VetAppDbContext>();
            optionsBuilder.UseMySql(
                "server=localhost;port=3306;database=vetappdb;user=root;password=159abugra357",
                new MySqlServerVersion(new Version(8, 0, 36))
            );

            return new VetAppDbContext(optionsBuilder.Options);
        }
    }
}
