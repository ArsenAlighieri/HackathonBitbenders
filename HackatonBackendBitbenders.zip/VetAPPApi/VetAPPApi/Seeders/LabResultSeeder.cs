﻿using VetAPPApi.Entity;

namespace VetAPPApi.Seeders
{
    public static class LabResultSeeder
    {
        public static void Seed(VetAppDbContext context)
        {
            // Gerekirse ekrana yaz
            Console.WriteLine("➡ Seeder çalıştırılıyor...");

            // Gerekirse bu kontrolü yoruma al
            if (context.LabResults.Any())
            {
                Console.WriteLine("✔ Zaten veri var, seed atlanıyor.");
                return;
            }

            var results = new List<LabResult>
            {
                // Kan Testleri
                new() { PatientId = 1, Type = "Kan", Category = "Karaciğer Fonksiyon Testleri", Name = "ALT (Alanin aminotransferaz)", Result = "48 U/L", Date = DateTime.Today },
                new() { PatientId = 1, Type = "Kan", Category = "Karaciğer Fonksiyon Testleri", Name = "AST (Aspartat aminotransferaz)", Result = "39 U/L", Date = DateTime.Today },
                new() { PatientId = 1, Type = "Kan", Category = "Enerji ve Lipid Metabolizması", Name = "Glukoz", Result = "105 mg/dL", Date = DateTime.Today },

                // İdrar Testleri
                new() { PatientId = 1, Type = "İdrar", Category = "Fiziksel Özellikler", Name = "Renk", Result = "Sarı", Date = DateTime.Today },
                new() { PatientId = 1, Type = "İdrar", Category = "Kimyasal Özellikler", Name = "Protein", Result = "Negatif", Date = DateTime.Today },
                new() { PatientId = 1, Type = "İdrar", Category = "Sediment Bulguları", Name = "Eritrosit (RBC)", Result = "0-3 /HPF", Date = DateTime.Today },
            };

            context.LabResults.AddRange(results);
            context.SaveChanges();
            Console.WriteLine("✅ Seed işlemi tamamlandı.");
        }
    }
}