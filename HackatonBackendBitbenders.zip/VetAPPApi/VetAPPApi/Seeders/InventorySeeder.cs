﻿using VetAPPApi.Entity;

namespace VetAPPApi.Seeders;

public static class InventorySeeder
{
    public static void SeedInventory(VetAppDbContext context)
    {
        if (!context.MedicineStocks.Any())
        {
            context.MedicineStocks.AddRange(
                new MedicineStock { Name = "Antibiyotik", Quantity = 120 },
                new MedicineStock { Name = "Ağrı Kesici", Quantity = 75 },
                new MedicineStock { Name = "Antiseptik Solüsyon", Quantity = 50 },
                new MedicineStock { Name = "Vitamin Takviyesi", Quantity = 90 }
            );
        }

        if (!context.MaterialStocks.Any())
        {
            context.MaterialStocks.AddRange(
                new MaterialStock { Name = "Enjektör", Quantity = 200 },
                new MaterialStock { Name = "Pamuk", Quantity = 300 },
                new MaterialStock { Name = "Steril Gazlı Bez", Quantity = 150 },
                new MaterialStock { Name = "Eldiven", Quantity = 500 }
            );
        }

        context.SaveChanges();
    }
}