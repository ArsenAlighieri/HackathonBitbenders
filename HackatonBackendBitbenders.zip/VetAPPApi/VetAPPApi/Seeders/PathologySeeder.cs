﻿using VetAPPApi.Entity;

namespace VetAPPApi.Seeders;

public static class PathologySeeder
{
    public static void Seed(VetAppDbContext context)
    {
        if (context.PathologyResults.Any()) return;

        var results = new List<PathologyResult>
        {
            new()
            {
                PatientId = 1,
                Tissue = "Karaciğer",
                ExaminationType = "Biyopsi",
                BiopsyType = "Cerrahi Biyopsi",
                Report = "Karaciğer dokusunda hepatosit dejenerasyonu tespit edildi.",
                PdfFilePath = null,
                Date = DateTime.Today
            },
            new()
            {
                PatientId = 1,
                Tissue = "Akciğer",
                ExaminationType = "Nekropsi",
                BiopsyType = null,
                Report = "Akciğer dokusunda pnömoni bulguları saptandı.",
                PdfFilePath = null,
                Date = DateTime.Today
            }
        };

        context.PathologyResults.AddRange(results);
        context.SaveChanges();
    }
}