﻿// Seeders/AppointmentSeeder.cs
using VetAPPApi.Entity;

namespace VetAPPApi.Seeders;

public static class AppointmentSeeder
{
    public static void Seed(VetAppDbContext context)
    {
        if (context.Appointments.Any()) return;

        var appointments = new List<Appointment>
        {
            new Appointment
            {
                PatientId = 1,
                AppointmentDate = DateTime.Today.AddHours(10),
                Description = "Genel muayene",
                Status = "Planned"
            },
            new Appointment
            {
                PatientId = 1,
                AppointmentDate = DateTime.Today.AddDays(1).AddHours(14),
                Description = "Kontrol randevusu",
                Status = "Planned"
            },
            new Appointment
            {
                PatientId = 2,
                AppointmentDate = DateTime.Today.AddDays(2).AddHours(11),
                Description = "Aşı takibi",
                Status = "Planned"
            }
        };

        context.Appointments.AddRange(appointments);
        context.SaveChanges();
    }
}