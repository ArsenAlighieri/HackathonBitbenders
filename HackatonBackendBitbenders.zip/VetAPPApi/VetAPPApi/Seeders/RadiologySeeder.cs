﻿using VetAPPApi.Entity;

namespace VetAPPApi.Seeders;

public static class RadiologySeeder
{
    public static void Seed(VetAppDbContext context)
    {
        if (context.RadiologyResults.Any()) return;

        var results = new List<RadiologyResult>
        {
            new()
            {
                PatientId = 1,
                ImageType = "Göğüs Röntgeni",
                ImagePath = "/Images/Radyoloji/gogus1.jpg",
                Comment = "Akciğer alanlarında infiltrasyon izlenmedi.",
                Date = DateTime.Today.AddDays(-3)
            },
            new()
            {
                PatientId = 1,
                ImageType = "Abdomen Röntgeni",
                ImagePath = "/Images/Radyoloji/abdomen1.jpg",
                Comment = "Barsak segmentlerinde aşırı gaz dağılımı mevcut.",
                Date = DateTime.Today.AddDays(-2)
            },
            new()
            {
                PatientId = 1,
                ImageType = "Kas-İskelet Röntgeni",
                ImagePath = "/Images/Radyoloji/kasiskelet1.jpg",
                Comment = "Distal femur hizasında çatlak görünümü.",
                Date = DateTime.Today.AddDays(-1)
            }
        };

        context.RadiologyResults.AddRange(results);
        context.SaveChanges();
    }
}