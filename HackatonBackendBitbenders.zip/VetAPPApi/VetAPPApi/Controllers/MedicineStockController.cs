﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/inventory/medications")]
public class MedicineStockController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public MedicineStockController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<StockDto>>> GetAll()
    {
        var result = await _context.MedicineStocks
            .Select(m => new StockDto
            {
                Name = m.Name,
                Stock = m.Quantity
            })
            .ToListAsync();

        return Ok(result);
    }
}