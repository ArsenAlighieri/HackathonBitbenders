﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi;
using VetAPPApi.Entity;

[ApiController]
[Route("api/[controller]")]
public class PrescriptionsController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public PrescriptionsController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PrescriptionDto>>> GetAll()
    {
        var list = await _context.Prescriptions
            .Select(p => new PrescriptionDto
            {
                Id = p.Id,
                PatientId = p.PatientId,
                Disease = p.Disease,
                Medications = p.Medications,
                Date = p.Date
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<PrescriptionDto>>> GetByPatient(int patientId)
    {
        var list = await _context.Prescriptions
            .Where(p => p.PatientId == patientId)
            .Select(p => new PrescriptionDto
            {
                Id = p.Id,
                PatientId = p.PatientId,
                Disease = p.Disease,
                Medications = p.Medications,
                Date = p.Date
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] PrescriptionCreateDto dto)
    {
        var entity = new Prescription
        {
            PatientId = dto.PatientId,
            Disease = dto.Disease,
            Medications = dto.Medications,
            Date = DateTime.Now
        };

        _context.Prescriptions.Add(entity);
        await _context.SaveChangesAsync();

        return Ok("Reçete kaydedildi.");
    }
}