﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RecoveryHistoriesController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public RecoveryHistoriesController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<RecoveryHistory>>> GetByPatientId(int patientId)
    {
        var records = await _context.RecoveryHistories
            .Where(x => x.PatientId == patientId)
            .ToListAsync();

        if (records == null || records.Count == 0)
        {
            return NotFound("Uyanma geçmişi bulunamadı.");
        }

        return Ok(records);
    }
}