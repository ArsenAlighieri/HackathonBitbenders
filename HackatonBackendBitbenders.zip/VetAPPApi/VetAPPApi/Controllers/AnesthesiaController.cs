﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AnesthesiaController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public AnesthesiaController(VetAppDbContext context)
    {
        _context = context;
    }

    // GET: api/anesthesiahistories/patient/5
    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<AnesthesiaHistory>>> GetByPatientId(int patientId)
    {
        var records = await _context.AnesthesiaHistory
            .Where(x => x.PatientId == patientId)
            .ToListAsync();

        if (records == null || records.Count == 0)
        {
            return NotFound("Anestezi geçmişi bulunamadı.");
        }

        return Ok(records);
    }
}