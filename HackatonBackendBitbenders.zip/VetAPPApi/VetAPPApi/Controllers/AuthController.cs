﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public AuthController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromQuery] string email, [FromQuery] string password)
    {
        var vet = await _context.Veterinarians.FirstOrDefaultAsync(v => v.Email == email);

        if (vet == null || vet.PasswordHash != password)
            return Unauthorized(new { message = "Geçersiz giriş." });

        return Ok(new { token = "dummy-token" }); // JWT eklenecek
    }
}
