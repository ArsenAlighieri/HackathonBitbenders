﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SurgeryHistoriesController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public SurgeryHistoriesController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<SurgeryHistory>>> GetByPatientId(int patientId)
    {
        var records = await _context.SurgeryHistories
            .Where(x => x.PatientId == patientId)
            .ToListAsync();

        if (records == null || records.Count == 0)
        {
            return NotFound("Operasyon geçmişi bulunamadı.");
        }

        return Ok(records);
    }
}