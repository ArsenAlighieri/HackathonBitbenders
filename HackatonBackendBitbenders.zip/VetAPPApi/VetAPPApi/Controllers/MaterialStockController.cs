﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/inventory/supplies")]
public class MaterialStockController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public MaterialStockController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<StockDto>>> GetAll()
    {
        var result = await _context.MaterialStocks
            .Select(m => new StockDto
            {
                Name = m.Name,
                Stock = m.Quantity
            })
            .ToListAsync();

        return Ok(result);
    }
}