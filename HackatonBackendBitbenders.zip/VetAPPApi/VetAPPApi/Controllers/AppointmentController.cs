﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AppointmentsController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public AppointmentsController(VetAppDbContext context)
    {
        _context = context;
    }

    // GET: api/appointments
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AppointmentDto>>> GetAll()
    {
        var list = await _context.Appointments
            .Select(a => new AppointmentDto
            {
                Id = a.Id,
                PatientId = a.PatientId,
                AppointmentDate = a.AppointmentDate,
                Description = a.Description,
                Status = a.Status
            })
            .ToListAsync();

        return Ok(list);
    }

    // ✅ GET: api/appointments/patient/5
    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<AppointmentDto>>> GetByPatientId(int patientId)
    {
        var list = await _context.Appointments
            .Where(a => a.PatientId == patientId)
            .Select(a => new AppointmentDto
            {
                Id = a.Id,
                PatientId = a.PatientId,
                AppointmentDate = a.AppointmentDate,
                Description = a.Description,
                Status = a.Status
            })
            .ToListAsync();

        if (!list.Any())
        {
            return NotFound("Bu hastaya ait randevu bulunamadı.");
        }

        return Ok(list);
    }

    // POST: api/appointments
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] AppointmentCreateDto dto)
    {
        var appointment = new Appointment
        {
            PatientId = dto.PatientId,
            AppointmentDate = dto.AppointmentDate,
            Description = dto.Description,
            Status = "Planned"
        };

        _context.Appointments.Add(appointment);
        await _context.SaveChangesAsync();

        return Ok("Randevu başarıyla eklendi.");
    }
}
