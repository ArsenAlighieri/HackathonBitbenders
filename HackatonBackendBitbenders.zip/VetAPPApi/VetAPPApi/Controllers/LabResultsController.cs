﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace VetAPPApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LabResultsController : ControllerBase
    {
        private readonly VetAppDbContext _context;

        public LabResultsController(VetAppDbContext context)
        {
            _context = context;
        }

        // GET: api/labresults/kan/1
        [HttpGet("kan/{patientId}")]
        public async Task<IActionResult> GetKanSonuclari(int patientId)
        {
            var results = await _context.LabResults
                .Where(r => r.PatientId == patientId && r.Type == "Kan")
                .ToListAsync();

            if (results == null || results.Count == 0)
                return NotFound("Kan sonuçları bulunamadı.");

            return Ok(results);
        }

        // GET: api/labresults/idrar/1
        [HttpGet("idrar/{patientId}")]
        public async Task<IActionResult> GetIdrarSonuclari(int patientId)
        {
            var results = await _context.LabResults
                .Where(r => r.PatientId == patientId && r.Type == "İdrar")
                .ToListAsync();

            if (results == null || results.Count == 0)
                return NotFound("İdrar sonuçları bulunamadı.");

            return Ok(results);
        }
    }
}