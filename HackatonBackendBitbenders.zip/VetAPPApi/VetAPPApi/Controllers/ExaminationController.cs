﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ExaminationsController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public ExaminationsController(VetAppDbContext context)
    {
        _context = context;
    }
    
    [HttpGet("patient/{patientId}")]
    public async Task<IActionResult> GetByPatientId(int patientId)
    {
        var list = await _context.Examinations
            .Where(e => e.PatientId == patientId)
            .OrderByDescending(e => e.Id)
            .ToListAsync();

        return Ok(list);
    }


    [HttpPost]
    public async Task<IActionResult> CreateExamination([FromBody] CreateExaminationDto dto)
    {
        var patient = await _context.Patients.FindAsync(dto.PatientId);
        if (patient == null)
            return NotFound("Hasta bulunamadı.");

        var examination = new Examination
        {
            PatientId = dto.PatientId,
            Travma = dto.Travma,
            Solunum = dto.Solunum,
            Ates = dto.Ates,
            Istah = dto.Istah,
            SuTuketimi = dto.SuTuketimi,
            Kusma = dto.Kusma,
            Diski = dto.Diski,
            Dehidrasyon = dto.Dehidrasyon,
            BulasiciHastalikSuphesi = dto.BulasiciHastalikSuphesi
        };

        _context.Examinations.Add(examination);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Muayene kaydedildi", examination.Id });
    }
}