﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;
namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/history/treatment")]
public class TreatmentHistoryController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public TreatmentHistoryController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet("{patientId}")]
    public async Task<ActionResult<IEnumerable<TreatmentHistoryDto>>> GetByPatientId(int patientId)
    {
        var list = await _context.TreatmentHistories
            .Where(h => h.PatientId == patientId)
            .Select(h => new TreatmentHistoryDto
            {
                Description = h.Description,
                Date = h.Date
            })
            .ToListAsync();

        return list.Count == 0 ? NotFound() : Ok(list);
    }
}
