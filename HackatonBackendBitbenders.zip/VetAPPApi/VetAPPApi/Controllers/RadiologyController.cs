﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RadiologyController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public RadiologyController(VetAppDbContext context)
    {
        _context = context;
    }

    // GET: api/radiology/patient/1
    [HttpGet("patient/{patientId}")]
    public async Task<IActionResult> GetByPatientId(int patientId)
    {
        var results = await _context.RadiologyResults
            .Where(r => r.PatientId == patientId)
            .ToListAsync();

        return Ok(results);
    }

    // POST: api/radiology/upload
    [HttpPost("upload")]
    public async Task<IActionResult> Upload([FromForm] RadiologyResultDto dto, IFormFile image)
    {
        if (image == null || image.Length == 0)
            return BadRequest("Görsel yüklenmedi.");

        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(image.FileName);
        var filePath = Path.Combine("wwwroot/radiology", fileName);

        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        using var stream = new FileStream(filePath, FileMode.Create);
        await image.CopyToAsync(stream);

        var result = new RadiologyResult
        {
            PatientId = dto.PatientId,
            ImageType = dto.ImageType,
            Comment = dto.Comment,
            ImagePath = "/radiology/" + fileName
        };

        _context.RadiologyResults.Add(result);
        await _context.SaveChangesAsync();

        return Ok("Radyoloji sonucu yüklendi.");
    }
}