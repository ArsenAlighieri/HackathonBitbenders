﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PatientsController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public PatientsController(VetAppDbContext context)
    {
        _context = context;
    }
    
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var patient = await _context.Patients
            .Include(p => p.Vaccines)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (patient == null) return NotFound();

        return Ok(patient);
    }
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdatePatient(int id, [FromBody] UpdatePatientDto dto)
    {
        var patient = await _context.Patients
            .Include(p => p.Vaccines)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (patient == null)
            return NotFound();

        // Ana bilgileri güncelle
        patient.Species = dto.Species;
        patient.Breed = dto.Breed;
        patient.BirthDate = dto.BirthDate;
        patient.IsNeutered = dto.IsNeutered;
        patient.Gender = dto.Gender;
        patient.Color = dto.Color;

        // Mevcut aşıları temizle
        _context.Vaccines.RemoveRange(patient.Vaccines);

        // Yeni aşıları ekle
        patient.Vaccines = dto.Vaccines.Select(v => new Vaccine
        {
            Name = v.Name,
            Date = v.Date,
            PatientId = patient.Id
        }).ToList();

        await _context.SaveChangesAsync();

        return Ok();
    }


    [HttpPost]
    public async Task<IActionResult> CreatePatient([FromBody] CreatePatientWithVaccinesDto dto)
    {
        var patient = new Patient
        {
            Species = dto.Species,
            Breed = dto.Breed,
            BirthDate = dto.BirthDate,
            IsNeutered = dto.IsNeutered,
            Gender = dto.Gender,
            Color = dto.Color,
            Vaccines = dto.Vaccines.Select(v => new Vaccine
            {
                Name = v.Name,
                Date = v.Date
            }).ToList()
        };

        _context.Patients.Add(patient);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Hasta kaydedildi.", patientId = patient.Id });
    }
}
