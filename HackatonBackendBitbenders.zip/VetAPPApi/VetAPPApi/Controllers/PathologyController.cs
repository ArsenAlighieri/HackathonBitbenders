﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PathologyController : ControllerBase
{
    private readonly VetAppDbContext _context;
    private readonly IWebHostEnvironment _env;

    public PathologyController(VetAppDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<PathologyResult>>> GetByPatientId(int patientId)
    {
        var results = await _context.PathologyResults
            .Where(r => r.PatientId == patientId)
            .ToListAsync();

        if (!results.Any())
            return NotFound("Patoloji sonucu bulunamadı.");

        return Ok(results);
    }

    [HttpPost("upload")]
    public async Task<IActionResult> Upload([FromForm] PathologyUploadDto dto)
    {
        string? pdfPath = null;

        if (dto.PdfFile != null && dto.PdfFile.Length > 0)
        {
            var uploadsDir = Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads");
            Directory.CreateDirectory(uploadsDir);
            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(dto.PdfFile.FileName)}";
            var filePath = Path.Combine(uploadsDir, fileName);

            using var stream = new FileStream(filePath, FileMode.Create);
            await dto.PdfFile.CopyToAsync(stream);

            pdfPath = $"/uploads/{fileName}";
        }

        var entity = new PathologyResult
        {
            PatientId = dto.PatientId,
            Tissue = dto.Tissue,
            ExaminationType = dto.ExaminationType,
            BiopsyType = dto.BiopsyType,
            Report = dto.Report,
            PdfFilePath = pdfPath,
            Date = DateTime.Now
        };

        _context.PathologyResults.Add(entity);
        await _context.SaveChangesAsync();

        return Ok("Patoloji kaydı başarıyla eklendi.");
    }
}
