﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VetAPPApi.Migrations
{
    /// <inheritdoc />
    public partial class AddSurgeryAndRecoveryHistories : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AnesthesiaHistory",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "RecoveryHistories",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 2,
                column: "PatientId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 1,
                column: "PatientId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 1);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AnesthesiaHistory",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "RecoveryHistories",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 2,
                column: "PatientId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 1,
                column: "PatientId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 3,
                column: "PatientId",
                value: 3);
        }
    }
}
