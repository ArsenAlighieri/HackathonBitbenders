﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace VetAPPApi.Migrations
{
    /// <inheritdoc />
    public partial class AddPrescriptionsWithJsonSupport : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AnesthesiaHistory",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "AnesthesiaHistory",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "AnesthesiaHistory",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "RecoveryHistories",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "RecoveryHistories",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "RecoveryHistories",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "SurgeryHistories",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "TreatmentHistories",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.CreateTable(
                name: "Prescriptions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    PatientId = table.Column<int>(type: "int", nullable: false),
                    Disease = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    MedicationsJson = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Medications = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Date = table.Column<DateTime>(type: "datetime(6)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Prescriptions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Prescriptions_Patients_PatientId",
                        column: x => x.PatientId,
                        principalTable: "Patients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_Prescriptions_PatientId",
                table: "Prescriptions",
                column: "PatientId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Prescriptions");

            migrationBuilder.InsertData(
                table: "AnesthesiaHistory",
                columns: new[] { "Id", "AnesthesiaType", "Date", "Description", "Notes", "PatientId" },
                values: new object[,]
                {
                    { 1, "", new DateTime(2024, 11, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "Anestezi tipi: Lokal", "", 1 },
                    { 2, "", new DateTime(2024, 8, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "Anestezi tipi: Lokal", "", 2 },
                    { 3, "", new DateTime(2024, 12, 19, 0, 0, 0, 0, DateTimeKind.Unspecified), "Anestezi tipi: Lokal", "", 2 }
                });

            migrationBuilder.InsertData(
                table: "RecoveryHistories",
                columns: new[] { "Id", "Date", "Description", "PatientId" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 2, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "Uyanma şekli: Yavaş", 1 },
                    { 2, new DateTime(2024, 9, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), "Uyanma şekli: Hızlı ve normal", 2 },
                    { 3, new DateTime(2024, 12, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), "Uyanma şekli: Yavaş", 1 }
                });

            migrationBuilder.InsertData(
                table: "SurgeryHistories",
                columns: new[] { "Id", "Date", "Description", "PatientId" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 3, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "Operasyon: Kısırlaştırma", 1 },
                    { 2, new DateTime(2024, 2, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), "Operasyon: Kısırlaştırma", 1 },
                    { 3, new DateTime(2024, 9, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "Operasyon: Tümör Alımı", 2 }
                });

            migrationBuilder.InsertData(
                table: "TreatmentHistories",
                columns: new[] { "Id", "Date", "Description", "PatientId" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 11, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "Tedavi uygulandı: Serum", 2 },
                    { 2, new DateTime(2024, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "Tedavi uygulandı: Serum", 2 },
                    { 3, new DateTime(2024, 7, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Tedavi uygulandı: Antibiyotik", 1 }
                });
        }
    }
}
