using Microsoft.EntityFrameworkCore;
using VetAPPApi;
using VetAPPApi.Seeders; // Seeder sınıfı burada
using VetAPPApi.Seeders;
var builder = WebApplication.CreateBuilder(args);

// 1. CORS Politikası
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});

// 2. DbContext - MySQL bağlantısı
builder.Services.AddDbContext<VetAppDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 36))));

// 3. Controller ve Swagger servisleri
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// Swagger - Çakışmaları önlemek için tam ad uzayı kullanılır
builder.Services.AddSwaggerGen(options =>
{
    options.CustomSchemaIds(type => type.FullName);
});

var app = builder.Build();

// 4. Middleware sıralaması
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowAll");
app.UseHttpsRedirection();
app.UseAuthorization();
app.UseStaticFiles(); // wwwroot klasöründen dosya sunmak için
app.MapControllers();

// 5. Seeder ile örnek verileri yükle
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<VetAppDbContext>();
    context.Database.Migrate();           // DB oluşturulmamışsa oluştur
    LabResultSeeder.Seed(context);        // Verileri yükle
}

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<VetAppDbContext>();
    VetAPPApi.Seeders.InventorySeeder.SeedInventory(db);
}



using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<VetAppDbContext>();
    context.Database.Migrate();
    LabResultSeeder.Seed(context);
    PathologySeeder.Seed(context);
    RadiologySeeder.Seed(context);// 👈 Bu satır eklenecek
    // Program.cs içinde seeding kısmına ekle:
    AppointmentSeeder.Seed(context);

}


// 6. Uygulamayı çalıştır
app.Run();