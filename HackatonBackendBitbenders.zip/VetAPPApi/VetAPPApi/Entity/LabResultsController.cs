﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace VetAPPApi.Entity;

[ApiController]
[Route("api/[controller]")]
public class LabResultsController : ControllerBase
{
    private readonly VetAppDbContext _context;

    public LabResultsController(VetAppDbContext context)
    {
        _context = context;
    }

    [HttpGet("{patientId}")]
    public async Task<IActionResult> GetLabResults(int patientId)
    {
        var results = await _context.LabResults
            .Where(r => r.PatientId == patientId)
            .Select(r => new LabResultDto
            {
                Type = r.Type,
                Category = r.Category,
                Name = r.Name,
                Result = r.Result,
                Date = r.Date
            })
            .ToListAsync();

        return Ok(results);
    }
}
