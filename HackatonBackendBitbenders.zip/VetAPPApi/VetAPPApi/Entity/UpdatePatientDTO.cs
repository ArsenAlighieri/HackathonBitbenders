﻿namespace VetAPPApi.Entity;

public class UpdatePatientDto
{
    public string Species { get; set; }
    public string Breed { get; set; }
    public DateTime BirthDate { get; set; }
    public bool IsNeutered { get; set; }
    public string Gender { get; set; }
    public string Color { get; set; }
    public List<VaccineDto> Vaccines { get; set; }
}

public class VaccineDto
{
    public string Name { get; set; }
    public DateTime Date { get; set; }
}
