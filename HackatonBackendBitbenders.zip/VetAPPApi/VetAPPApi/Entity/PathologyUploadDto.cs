﻿namespace VetAPPApi.Entity
{
    public class PathologyUploadDto
    {
        public int PatientId { get; set; }
        public string Tissue { get; set; } = string.Empty;
        public string ExaminationType { get; set; } = string.Empty;
        public string? BiopsyType { get; set; }
        public string Report { get; set; } = string.Empty;
        public IFormFile? PdfFile { get; set; }
    }
}