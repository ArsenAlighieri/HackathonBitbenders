﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VetAPPApi.Entity
{
    public class LabResult
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int PatientId { get; set; }

        [Required]
        [MaxLength(20)]
        public string Type { get; set; }  // "Kan" veya "İdrar"

        [Required]
        [MaxLength(100)]
        public string Category { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }  // Test adı

        [Required]
        [MaxLength(50)]
        public string Result { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [ForeignKey("PatientId")]
        public Patient Patient { get; set; }  // Navigation Property (opsiyonel)
    }
}