﻿namespace VetAPPApi.Entity;

public class Examination
{
    public int Id { get; set; }
    public int PatientId { get; set; }
    public string Travma { get; set; }
    public string Solunum { get; set; }
    public string Ates { get; set; }
    public string Istah { get; set; }
    public string SuTuketimi { get; set; }
    public string Kusma { get; set; }
    public string Diski { get; set; }
    public string Dehidrasyon { get; set; }
    public string BulasiciHastalikSuphesi { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Patient Patient { get; set; }
}
