﻿namespace VetAPPApi.Entity
{
    public class SurgeryHistory
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public string Description { get; set; } = string.Empty;
        public DateTime Date { get; set; } = DateTime.Now;

        public Patient? Patient { get; set; }
    }
}