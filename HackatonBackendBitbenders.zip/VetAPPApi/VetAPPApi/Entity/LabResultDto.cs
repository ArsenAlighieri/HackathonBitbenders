﻿namespace VetAPPApi.Entity;

public class LabResultDto
{
    public string Type { get; set; }
    public string Category { get; set; }
    public string Name { get; set; }
    public string Result { get; set; }
    public DateTime Date { get; set; }
}
