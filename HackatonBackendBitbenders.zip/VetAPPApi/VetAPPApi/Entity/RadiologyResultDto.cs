﻿namespace VetAPPApi.Entity;

public class RadiologyResultDto
{
    public int PatientId { get; set; }
    public string ImageType { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;
}