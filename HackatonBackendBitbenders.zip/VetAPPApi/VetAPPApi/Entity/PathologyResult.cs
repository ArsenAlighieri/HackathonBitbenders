﻿namespace VetAPPApi.Entity;

public class PathologyResult
{
    public int Id { get; set; }
    public int PatientId { get; set; }
    public string Tissue { get; set; } = string.Empty;
    public string ExaminationType { get; set; } = string.Empty; // Biyopsi veya Nekropsi
    public string? BiopsyType { get; set; } // Biyopsi türü varsa
    public string Report { get; set; } = string.Empty;
    public string? PdfFilePath { get; set; }
    public DateTime Date { get; set; } = DateTime.Now;

    public Patient? Patient { get; set; }
}
