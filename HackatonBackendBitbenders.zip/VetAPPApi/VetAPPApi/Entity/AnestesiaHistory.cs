﻿namespace VetAPPApi.Entity
{
    public class AnesthesiaHistory
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;
        public string AnesthesiaType { get; set; } = string.Empty; // Örn: Genel, Lokal
        public string Notes { get; set; } = string.Empty;

        public Patient? Patient { get; set; }
        public string Description { get; set; }
    }
}