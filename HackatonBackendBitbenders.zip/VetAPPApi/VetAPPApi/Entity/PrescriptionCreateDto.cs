﻿namespace VetAPPApi.Entity;

public class PrescriptionCreateDto
{
    public int PatientId { get; set; }
    public string Disease { get; set; } = string.Empty;
    public List<string> Medications { get; set; } = new();
}
