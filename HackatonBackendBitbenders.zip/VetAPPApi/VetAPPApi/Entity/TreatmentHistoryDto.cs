﻿namespace VetAPPApi;

public class TreatmentHistoryDto
{
    public string Description { get; set; } = string.Empty;
    public DateTime Date { get; set; }
}
