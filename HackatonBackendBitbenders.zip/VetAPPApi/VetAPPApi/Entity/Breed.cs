﻿namespace VetAPPApi.Entity;

public class Breed
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Species { get; set; } = null!; // Opsiyonel: Köpek, Kedi, vs.

    public ICollection<Patient> Patients { get; set; } = new List<Patient>();
}