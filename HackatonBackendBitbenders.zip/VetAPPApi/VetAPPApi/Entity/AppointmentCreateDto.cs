﻿// Dto/AppointmentCreateDto.cs
namespace VetAPPApi.Entity;

public class AppointmentCreateDto
{
    public int PatientId { get; set; }
    public DateTime AppointmentDate { get; set; }
    public string? Description { get; set; }
}