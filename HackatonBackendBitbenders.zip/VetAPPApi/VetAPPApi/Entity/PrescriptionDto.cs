﻿namespace VetAPPApi.Entity;

public class PrescriptionDto
{
    public int Id { get; set; }
    public int PatientId { get; set; }
    public string Disease { get; set; } = string.Empty;
    public List<string> Medications { get; set; } = new();
    public DateTime Date { get; set; }
}
