﻿namespace VetAPPApi;

public class VaccineDto
{
    public string Name { get; set; } = null!;
    public DateTime Date { get; set; }
}

public class CreatePatientWithVaccinesDto
{
    public string Species { get; set; } = null!;
    public string Breed { get; set; } = null!;
    public DateTime BirthDate { get; set; }
    public bool IsNeutered { get; set; }
    public string Gender { get; set; } = null!;
    public string Color { get; set; } = null!;
    public List<VaccineDto> Vaccines { get; set; } = new();
}