﻿namespace VetAPPApi.Entity;

public class RadiologyResult
{
    public int Id { get; set; }
    public int PatientId { get; set; }
    public string ImageType { get; set; } = string.Empty; // Örn: Göğüs Röntgeni
    public string ImagePath { get; set; } = string.Empty; // Sunucudaki dosya yolu
    public string Comment { get; set; } = string.Empty;   // Hekim yorumu
    public DateTime Date { get; set; } = DateTime.Now;

    public Patient? Patient { get; set; }
}