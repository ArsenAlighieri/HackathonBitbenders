﻿using System.Text.Json.Serialization;

namespace VetAPPApi.Entity;

public class Vaccine
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public DateTime Date { get; set; }

    public int PatientId { get; set; }
    [JsonIgnore]
    public Patient Patient { get; set; }

}
