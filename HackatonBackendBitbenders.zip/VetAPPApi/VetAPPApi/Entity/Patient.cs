﻿namespace VetAPPApi.Entity;

public class Patient
{
    public int Id { get; set; }
    public string Species { get; set; } = null!;
    
    public string Breed { get; set; } = null!;
    public DateTime BirthDate { get; set; }
    public bool IsNeutered { get; set; }
    public string Gender { get; set; } = null!;
    public string Color { get; set; } = null!;
    public ICollection<Vaccine> Vaccines { get; set; } = new List<Vaccine>();
}
