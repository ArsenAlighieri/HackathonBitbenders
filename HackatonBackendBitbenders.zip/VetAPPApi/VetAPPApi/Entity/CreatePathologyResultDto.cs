﻿namespace VetAPPApi.Entity;

public class CreatePathologyResultDto
{
    public int PatientId { get; set; }
    public string Tissue { get; set; } = string.Empty;
    public string ExaminationType { get; set; } = string.Empty;
    public string? BiopsyType { get; set; }
    public string Report { get; set; } = string.Empty;
}
