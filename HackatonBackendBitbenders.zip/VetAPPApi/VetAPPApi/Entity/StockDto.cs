﻿namespace VetAPPApi.Entity
{
    public class StockDto
    {
        public string Name { get; set; } = string.Empty;
        public int Stock { get; set; }
    }
}