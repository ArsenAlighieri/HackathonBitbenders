﻿using System.Text.Json;
using VetAPPApi.Entity;

public class Prescription
{
    public int Id { get; set; }
    public int PatientId { get; set; }
    public string Disease { get; set; } = string.Empty;

    public string MedicationsJson { get; set; } = "[]";

    public List<string> Medications
    {
        get => JsonSerializer.Deserialize<List<string>>(MedicationsJson) ?? new();
        set => MedicationsJson = JsonSerializer.Serialize(value);
    }

    public DateTime Date { get; set; }

    public Patient? Patient { get; set; }   
}