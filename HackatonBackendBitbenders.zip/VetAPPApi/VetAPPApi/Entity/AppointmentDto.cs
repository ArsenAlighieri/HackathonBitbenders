﻿// Dto/AppointmentDto.cs
namespace VetAPPApi.Entity;

public class AppointmentDto
{
    public int Id { get; set; }
    public int PatientId { get; set; }
    public DateTime AppointmentDate { get; set; }
    public string? Description { get; set; }
    public string Status { get; set; } = "Planned";
}