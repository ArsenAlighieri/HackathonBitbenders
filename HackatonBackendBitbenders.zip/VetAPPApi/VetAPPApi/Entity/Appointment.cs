﻿namespace VetAPPApi.Entity
{
    public class Appointment
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public DateTime AppointmentDate { get; set; }
        public string? Description { get; set; }
        public string Status { get; set; } = "Planlandı";

        public Patient? Patient { get; set; }
    }
}