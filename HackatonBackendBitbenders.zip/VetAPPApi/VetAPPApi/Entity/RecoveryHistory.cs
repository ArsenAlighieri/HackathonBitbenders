﻿namespace VetAPPApi.Entity
{
    public class RecoveryHistory
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public string Description { get; set; } = string.Empty;
        public DateTime Date { get; set; } = DateTime.Now;

        public Patient? Patient { get; set; }
    }
}