﻿using Microsoft.EntityFrameworkCore;
using VetAPPApi.Entity;

namespace VetAPPApi;

public class VetAppDbContext : DbContext
{
    public VetAppDbContext(DbContextOptions<VetAppDbContext> options) : base(options) { }
    
    public DbSet<Veterinarian> Veterinarians { get; set; }
    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<Vaccine> Vaccines => Set<Vaccine>();
    public DbSet<Examination> Examinations { get; set; }
    public DbSet<LabResult> LabResults { get; set; }
    public DbSet<PathologyResult> PathologyResults { get; set; }
    public DbSet<RadiologyResult> RadiologyResults { get; set; }
    public DbSet<Appointment> Appointments { get; set; }
    public DbSet<MedicineStock> MedicineStocks { get; set; }
    public DbSet<MaterialStock> MaterialStocks { get; set; }
    public DbSet<TreatmentHistory> TreatmentHistories { get; set; }
    public DbSet<AnesthesiaHistory> AnesthesiaHistory { get; set; }
    public DbSet<SurgeryHistory> SurgeryHistories { get; set; }
    public DbSet<RecoveryHistory> RecoveryHistories { get; set; }
    public DbSet<Prescription> Prescriptions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        
        // Gerekirse özel konfigürasyonlar buraya
    }

    // Diğer DbSet'ler buraya gelecek
}
